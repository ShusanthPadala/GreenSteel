package com.greensteel.security;

import com.greensteel.security.service.PasswordResetService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.context.annotation.Profile;

@RestController
@Profile("dev")
@RequestMapping("/api/auth/dev")
@RequiredArgsConstructor
public class DevPasswordResetController {
    private final PasswordResetService passwordResetService;

    @GetMapping("/reset-link")
    public ResponseEntity<?> getResetLink(@RequestParam String email) {
        String resetUrl = passwordResetService.getDevelopmentResetUrl(email);
        if (resetUrl == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(java.util.Map.of("resetUrl", resetUrl));
    }
}
